# SentinelGuard 🛡️

SentinelGuard is an advanced, privacy-first Android system monitoring and forensic auditing tool designed to run entirely **without root or Shizuku privileges**. It maintains a tamper-evident, hash-chained local audit trail of every critical system change, app modification, permission escalation, and security event.

## 🚀 Core Features Matrix (All 28 Modules)

1. **Live Foreground Monitor**: Real-time tracking of active package activities via `UsageStatsManager` and accessibility hooks.
2. **Instant Install/Update/Uninstall Alerts**: Broadcast receiver triggers immediate high-priority notifications on package lifecycle events.
3. **Permanent History Log**: Local Room SQLite database configured for 30+ day retention with automated background pruning.
4. **Tamper-Evident Hash-Chained Log**: Every log entry includes a SHA-256 cryptographic hash tied to the previous entry, preventing undetected log tampering.
5. **Flagged App Alerts**: Heuristic signature and package scanning for known root tools, hooking frameworks (Xposed/Frida indicators), mods, and cheat engines.
6. **New Dangerous Permission Alerts**: Scans newly requested permissions against a predefined dangerous permission matrix (`READ_CONTACTS`, `ACCESS_FINE_LOCATION`, `BIND_ACCESSIBILITY_SERVICE`, etc.).
7. **Residual File Watcher**: Monitors primary storage directories for leftover app folders after uninstalls.
8. **Developer & Debugging Watcher**: Continuous observer for changes in USB Debugging, Wireless Debugging, and Unknown Sources flags via `Settings.Secure`.
9. **Clock Change Alerts**: Intercepts `ACTION_TIME_CHANGED` and `ACTION_TIMEZONE_CHANGED` broadcasts to detect anti-forensic time tampering.
10. **VPN, Proxy & Accessibility Service Watcher**: Audits active VPN profiles, proxy configurations, and newly enabled accessibility services.
11. **Screen & Lock Event Log**: Tracks screen-on, screen-off, and device unlock cryptographic challenges.
12. **Search, Filters & Timeline**: Indexed queries over SQLite logs ranging from 24 hours to 30 days.
13. **Copy & Export Engine**: Serializes audit logs into formatted TXT, JSON, and CSV payloads.
14. **Foreground Service**: Persistent notification daemon ensuring uninterrupted background observation.
15. **Notification Log**: Intercepts and archives incoming notification metadata via NotificationListenerService.
16. **Signature Change Alert**: Compares installed APK signing certificate digests against baseline records on every update.
17. **Odd-Hours Detector**: Flags system events, app launches, or modifications occurring during suspicious user-defined windows (e.g., 02:00–05:00 AM).
18. **Snapshot Compare**: Point-in-time diff tool comparing installed package state tables between two historical dates.
19. **Charging & Battery Log**: Monitors power connection states, charging speed anomalies, and battery temperature thresholds.
20. **Network Change Log**: Tracks Wi-Fi SSID transitions, cellular network switching, and captive portal detections.
21. **New File & APK Watcher**: `FileObserver` integration scanning download directories for newly dropped APK binaries.
22. **PIN / Fingerprint Lock**: BiometricPrompt authentication layer protecting app access.
23. **Encrypted Backup & Restore**: AES-GCM encrypted local exports of database archives.
24. **Self-Guard Against Permission Removal**: Watchdog monitoring critical permissions to prevent accidental revocation.
25. **Device Admin Uninstall Protection**: Optional Device Administrator policy preventing unauthorized app removal.
26. **Custom Watchlist Rules**: User-defined regex and keyword rules triggering custom alert actions.
27. **Auto-Start, Widget & Quick Tile**: Boot persistence (`BOOT_COMPLETED`), home screen widgets, and a Quick Settings tile for instant status toggling.
28. **Weekly Summary Report**: Automated background worker compiling weekly threat and event analytics.
