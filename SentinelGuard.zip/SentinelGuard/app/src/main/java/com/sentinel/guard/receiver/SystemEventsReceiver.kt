package com.sentinel.guard.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                Log.w("SentinelGuard", "Clock change event detected!")
            }
            Intent.ACTION_POWER_CONNECTED -> {
                Log.i("SentinelGuard", "Power connected")
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                Log.i("SentinelGuard", "Power disconnected")
            }
        }
    }
}
