package com.sentinel.guard.security

import com.sentinel.guard.data.AuditLogEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportEngine {

    fun exportToCSV(logs: List<AuditLogEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Timestamp,Date,EventType,Category,Details,PreviousHash,CurrentHash,IsFlagged
")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        for (log in logs) {
            val dateStr = sdf.format(Date(log.timestamp))
            val safeDetails = log.details.replace(""", """")
            sb.append(""${log.id}",${log.timestamp},"$dateStr","${log.eventType}","${log.category}","$safeDetails","${log.previousHash}","${log.currentHash}",${log.isFlagged}
")
        }
        return sb.toString()
    }

    fun exportToJSON(logs: List<AuditLogEntity>): String {
        val sb = StringBuilder()
        sb.append("[
")
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
        for (i in logs.indices) {
            val log = logs[i]
            val dateStr = sdf.format(Date(log.timestamp))
            val safeDetails = log.details.replace(""", "\"").replace("
", "\n")
            sb.append("  {
")
            sb.append("    "id": "${log.id}",
")
            sb.append("    "timestamp": ${log.timestamp},
")
            sb.append("    "datetime": "$dateStr",
")
            sb.append("    "eventType": "${log.eventType}",
")
            sb.append("    "category": "${log.category}",
")
            sb.append("    "details": "$safeDetails",
")
            sb.append("    "previousHash": "${log.previousHash}",
")
            sb.append("    "currentHash": "${log.currentHash}",
")
            sb.append("    "isFlagged": ${log.isFlagged}
")
            sb.append("  }${if (i < logs.size - 1) "," else ""}
")
        }
        sb.append("]")
        return sb.toString()
    }

    fun exportToTXT(logs: List<AuditLogEntity>): String {
        val sb = StringBuilder()
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        sb.append("=== SENTINELGUARD AUDIT LOG REPORT ===
")
        sb.append("Total Records: ${logs.size}
")
        sb.append("Generated: ${sdf.format(Date())}
")
        sb.append("=========================================

")
        for (log in logs) {
            sb.append("[${sdf.format(Date(log.timestamp))}] TYPE: ${log.eventType} | CAT: ${log.category}
")
            sb.append("Details: ${log.details}
")
            sb.append("Hash: ${log.currentHash}
")
            sb.append("Prev: ${log.previousHash}
")
            sb.append("-----------------------------------------
")
        }
        return sb.toString()
    }
}
