package com.sentinel.guard.security

import android.content.Context
import android.content.pm.PackageManager
import java.io.File

object FlaggedAppAnalyzer {

    private val SUSPICIOUS_PACKAGES = setOf(
        "com.topjohnwu.magisk",
        "eu.chainfire.supersu",
        "com.noshufou.android.su",
        "com.koushikdutta.superuser",
        "com.thirdparty.superuser",
        "com.yellowes.su",
        "com.koushikdutta.rommanager",
        "com.dimonvideo.luckypatcher",
        "com.chelpus.lackypatch",
        "catch_.me_.if_.you_.can_",
        "org.meowcat.edxposed.manager",
        "org.lsposed.manager"
    )

    fun isFlaggedApp(packageName: String): Boolean {
        return SUSPICIOUS_PACKAGES.contains(packageName.lowercase())
    }

    fun detectRootOrHooks(): List<String> {
        val Detections = mutableListOf<String>()
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (File(path).exists()) {
                Detections.add("Binary found: $path")
            }
        }
        return Detections
    }
}
