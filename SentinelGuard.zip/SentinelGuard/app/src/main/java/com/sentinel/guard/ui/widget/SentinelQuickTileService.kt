package com.sentinel.guard.ui.widget

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log

class SentinelQuickTileService : TileService() {

    override fun onClick() {
        super.onClick()
        val tile = qsTile
        if (tile.state == Tile.STATE_ACTIVE) {
            tile.state = Tile.STATE_INACTIVE
            Log.i("SentinelTile", "Monitoring paused")
        } else {
            tile.state = Tile.STATE_ACTIVE
            Log.i("SentinelTile", "Monitoring activated")
        }
        tile.updateTile()
    }
}
