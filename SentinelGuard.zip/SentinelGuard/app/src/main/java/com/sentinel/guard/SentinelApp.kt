package com.sentinel.guard

import android.app.Application

class SentinelApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
