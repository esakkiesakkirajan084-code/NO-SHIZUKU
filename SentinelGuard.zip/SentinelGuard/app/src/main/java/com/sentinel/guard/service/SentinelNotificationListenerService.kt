package com.sentinel.guard.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class SentinelNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.let {
            val packageName = it.packageName
            val title = it.notification.extras.getString("android.title") ?: ""
            Log.d("SentinelNotifListener", "Notification from $packageName: $title")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Log removed notifications if needed
    }
}
