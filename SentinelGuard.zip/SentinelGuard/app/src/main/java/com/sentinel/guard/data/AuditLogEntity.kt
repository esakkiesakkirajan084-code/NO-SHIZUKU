package com.sentinel.guard.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val eventType: String,
    val details: String,
    val previousHash: String,
    val currentHash: String,
    val isFlagged: Boolean = false,
    val category: String = "GENERAL"
)
