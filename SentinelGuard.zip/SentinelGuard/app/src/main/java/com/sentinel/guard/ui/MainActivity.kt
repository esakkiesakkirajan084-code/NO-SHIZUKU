package com.sentinel.guard.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.sentinel.guard.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate()
        setContentView(R.layout.activity_main)
    }
}
