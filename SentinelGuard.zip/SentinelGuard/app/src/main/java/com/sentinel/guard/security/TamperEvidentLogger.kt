package com.sentinel.guard.security

import com.sentinel.guard.data.AuditLogEntity
import java.security.MessageDigest
import java.util.UUID

object TamperEvidentLogger {

    fun createLogEntry(eventType: String, details: String, previousHash: String): AuditLogEntity {
        val timestamp = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val currentHash = computeHash(timestamp, eventType, details, previousHash)
        return AuditLogEntity(
            id = id,
            timestamp = timestamp,
            eventType = eventType,
            details = details,
            previousHash = previousHash,
            currentHash = currentHash
        )
    }

    fun computeHash(timestamp: Long, eventType: String, details: String, previousHash: String): String {
        val payload = "$timestamp|$eventType|$details|$previousHash"
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(payload.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyChain(entries: List<AuditLogEntity>): Boolean {
        for (i in 1 until entries.size) {
            val prev = entries[i - 1]
            val curr = entries[i]
            if (curr.previousHash != prev.currentHash) return false
            val expectedHash = computeHash(curr.timestamp, curr.eventType, curr.details, curr.previousHash)
            if (curr.currentHash != expectedHash) return false
        }
        return true
    }
}
