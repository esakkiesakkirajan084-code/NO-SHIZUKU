package com.sentinel.guard.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

class SentinelAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            if (it.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                val packageName = it.packageName?.toString() ?: ""
                val className = it.className?.toString() ?: ""
                Log.d("SentinelAccessibility", "Foreground Window Changed: $packageName / $className")
            }
        }
    }

    override fun onInterrupt() {
        Log.w("SentinelAccessibility", "Accessibility service interrupted")
    }
}
