package com.sentinel.guard.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val packageName = intent.data?.schemeSpecificPart ?: return

        when (action) {
            Intent.ACTION_PACKAGE_ADDED -> {
                Log.i("SentinelGuard", "New package installed: $packageName")
            }
            Intent.ACTION_PACKAGE_REPLACED -> {
                Log.i("SentinelGuard", "Package updated/signature checked: $packageName")
            }
            Intent.ACTION_PACKAGE_REMOVED -> {
                Log.i("SentinelGuard", "Package uninstalled: $packageName - initiating residual file check")
            }
        }
    }
}
